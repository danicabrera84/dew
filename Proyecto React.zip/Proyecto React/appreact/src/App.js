import React, {useState} from 'react';

import Login from './componentes/Login';
import Crud from './componentes/Crud';

function App() {

const [conectado, setConectado] = useState(false);

const acceder =(estado)=>{
  setConectado(estado)
}

  return (
    conectado ? <Crud /> : <Login acceder={acceder}/>
  );
}

export default App;