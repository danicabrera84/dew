import React, {useRef, useState} from 'react';
import '../css/login.css';
import '../css/bootstrap.min.css';
import  logo from '../img/logo.PNG';


const URL_LOGIN = "https://react.cpid.es/login.php";

const enviarData = async (url, data)=>{

    const resp = await fetch(url, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json'
        }
    });

    //console.log(resp);
    const json = await resp.json();
    //console.log(json);

    return json;
}


export default function Login(props) {

const refUsuario = useRef(null);
const refClave = useRef(null);
const [error, setError]=useState(null);

const handleLogin= async()=>{
    const data = {
        "usuario": refUsuario.current.value,
        "clave": refClave.current.value
    };
    const respuestaJson = await enviarData (URL_LOGIN, data);
    console.log("respuesta desde el evento", respuestaJson);

    props.acceder(respuestaJson.conectado)
    setError(respuestaJson.error)
}

    return(
        <div className="login">
            <div className="row">
                <div className="col-sm-4 offset-4 mt-5">
                    <div className="card pt-5">
                        <div className="card-header">
                        <img src={logo} alt="logo" />
                        </div>
                        <div className="card-body">
                            <div className="input-group mb-3">
                                <span className="input-group-text" id="basic-addon1">📧</span>
                                <input type="email" className="form-control" placeholder="correo" aria-label="Username" aria-describedby="basic-addon1" ref={refUsuario} />
                            </div>
                            <div className="input-group mb-3">
                                <span className="input-group-text" id="basic-addon2">🔒</span>
                                <input type="password" className="form-control" placeholder="clave" aria-label="clave" aria-describedby="basic-addon2" ref={refClave} />
                            </div>


                            {
                                error &&
                                <div className="alert alert-danger">
                                    {error}
                                </div>
                            }
                            

                            <div className="d-grid gap-2">
                                <button onClick={handleLogin} className="btn btn-primary" type="button">Acceder</button>
                            </div>
                            
                            <div className="card-footer">
                                <span>Olvido su contrasena?</span>{" "}<a href="">recuperar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}