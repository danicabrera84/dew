import React from "react";
import logo from "../logo.svg";
import "../App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import {
    Table,
    Button,
    Container,
    Modal,
    ModalHeader,
    ModalBody,
    FormGroup,
    ModalFooter,
  } from "reactstrap";
const data = [
    { id: 1, nombre: "Daniel", apellido: "Cabrera", telefono: "626096990", edad: "36", correo: "dcabrera@copicanarias.es", info: "" },
  ];
export default class Crud extends React.Component {
    state = {
      data: data,
      modalActualizar: false,
      modalInsertar: false,
      form: {
        id: "",
        nombre: "",
        apellido: "",
        telefono: "",
        edad: "",
        correo: "",
        info: "",
      },
    };

    onImageChange = (event) => {
      if (event.target.files && event.target.files[0]) {
        let reader = new FileReader();
        reader.onload = (e) => {
          this.setState({image: e.target.result});
        };
        reader.readAsDataURL(event.target.files[0]);
      }
    }

    mostrarModalActualizar = (dato) => {
      this.setState({
        form: dato,
        modalActualizar: true,
      });
    };
  
    cerrarModalActualizar = () => {
      this.setState({ modalActualizar: false });
    };
  
    mostrarModalInsertar = () => {
      this.setState({
        modalInsertar: true,
      });
    };
  
    cerrarModalInsertar = () => {
      this.setState({ modalInsertar: false });
      <img id="target" src="#"/>
    };
  
    editar = (dato) => {
      var contador = 0;
      var array = this.state.data;
      array.map((registro) => {
        if (dato.id == registro.id) {
          array[contador].nombre = dato.nombre;
          array[contador].apellido = dato.apellido;
          array[contador].telefono = dato.telefono;
          array[contador].edad = dato.edad;
          array[contador].correo = dato.correo;
          array[contador].info = dato.info;
        }
        contador++;
      });
      this.setState({ data: array, modalActualizar: false });
    };
  
    eliminar = (dato) => {
      var opcion = window.confirm("Deseas eliminar el cliente "+dato.nombre+" "+dato.apellido+"?");
      if (opcion == true) {
        var contador = 0;
        var array = this.state.data;
        array.map((registro) => {
          if (dato.id == registro.id) {
            array.splice(contador, 1);
          }
          contador++;
        });
        this.setState({ data: array, modalActualizar: false });
      }
      alert("El cliente "+dato.nombre+" "+dato.apellido+" ha sido eliminado");
    };
  
    insertar= ()=>{
      var valorNuevo= {...this.state.form};
      valorNuevo.id=this.state.data.length+1;
      var lista= this.state.data;
      lista.push(valorNuevo);
      this.setState({ modalInsertar: false, data: lista });
      if (valorNuevo.edad < 18) {
        alert("El cliente no puede ser menor de edad");
        lista.pop(valorNuevo);
      }
    }
  
    handleChange = (e) => {
      this.setState({
        form: {
          ...this.state.form,
          [e.target.name]: e.target.value,
        },
      });
    };
  
    render() {
      
      return (
        <>
          <Container>
            <br/>
            <Button color="success" onClick={()=>this.mostrarModalInsertar()}>Insertar Cliente</Button>
            <br/>
            <br />
            <Table>
              <thead>
                <tr>
                  <th>id</th>
                  <th>Nombre</th>
                  <th>Apellido</th>
                  <th>Telefono</th>
                  <th>Edad</th>
                  <th>Correo</th>
                  <th>Informacion</th>
                </tr>
              </thead>
  
              <tbody>
                {this.state.data.map((dato) => (
                  <tr key={dato.id}>
                    <td>{dato.id}</td>
                    <td>{dato.nombre}</td>
                    <td>{dato.apellido}</td>
                    <td>{dato.telefono}</td>
                    <td>{dato.edad}</td>
                    <td>{dato.correo}</td>
                    <td>{dato.info}</td>
                    <td>
                      <Button color="primary" onClick={() => this.mostrarModalActualizar(dato)}>Editar</Button>{" "}
                      <Button color="danger" onClick={()=> this.eliminar(dato)}>Eliminar</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Container>
  
          <Modal isOpen={this.state.modalActualizar}>
            <ModalHeader>
             <div><h3>Editar Registro</h3></div>
            </ModalHeader>
  
            <ModalBody>
              <FormGroup>
                <label>id:</label>
                <input className="form-control" readOnly type="text" value={this.state.form.id}/>
              </FormGroup>
              
              <FormGroup>
                <label>Nombre:</label>
                <input className="form-control" name="nombre" type="text" onChange={this.handleChange} value={this.state.form.nombre}/>
              </FormGroup>
  
              <FormGroup>
                <label>Apellido:</label>
                <input className="form-control" name="apellido" type="text" onChange={this.handleChange} value={this.state.form.apellido}/>
              </FormGroup>
  
              <FormGroup>
                <label>Telefono:</label>
                <input className="form-control" name="telefono" type="text" onChange={this.handleChange} value={this.state.form.telefono}/>
              </FormGroup>
  
              <FormGroup>
                <label>Edad:</label>
                <input className="form-control" name="edad" type="text" onChange={this.handleChange} value={this.state.form.edad}/>
              </FormGroup>
  
              <FormGroup>
                <label>Correo:</label>
                <input className="form-control" name="correo" type="text" onChange={this.handleChange} value={this.state.form.correo}/>
              </FormGroup>
  
              <FormGroup>
                <label>Informacion:</label>
                <input className="form-control" name="info" type="text" onChange={this.handleChange} value={this.state.form.info}/>
              </FormGroup>
            </ModalBody>
  
            <ModalFooter>
              <Button color="success" onClick={() => this.editar(this.state.form)}>Modificar</Button>
              <Button color="danger" onClick={() => this.cerrarModalActualizar()}>Cancelar</Button>
            </ModalFooter>
          </Modal>
  
  
  
          <Modal isOpen={this.state.modalInsertar}>
            <ModalHeader>
             <div><h3>Insertar Cliente</h3></div>
            </ModalHeader>
  
            <ModalBody>
              <FormGroup>
                <label>id:</label>
                <input className="form-control" readOnly type="text" value={this.state.data.length+1}/>
              </FormGroup>
            
              <FormGroup>
                <label>Nombre:</label>
                <input className="form-control" name="nombre" type="text" onChange={this.handleChange}/>
              </FormGroup>
              
              <FormGroup>
                <label>Apellido:</label>
                <input className="form-control" name="apellido" type="text" onChange={this.handleChange}/>
              </FormGroup>
  
              <FormGroup>
                <label>Telefono:</label>
                <input className="form-control" name="telefono" type="text" onChange={this.handleChange}/>
              </FormGroup>
  
              <FormGroup>
                <label>Edad:</label>
                <input className="form-control" name="edad" type="text" onChange={this.handleChange}/>
              </FormGroup>
  
              <FormGroup>
                <label>Correo:</label>
                <input className="form-control" name="correo" type="text" onChange={this.handleChange}/>
              </FormGroup>
  
              <FormGroup>
                <label>Informacion:</label>
                <input className="form-control" name="info" type="text" onChange={this.handleChange}/>
              </FormGroup>

              <FormGroup>
              <input type="file" onChange={this.onImageChange} className="filetype" id="group_image"/>
              <img id="target" src={this.state.image}/>
              </FormGroup>
            </ModalBody>
  
            <ModalFooter>
              <Button color="success" onClick={() => this.insertar()}>Insertar</Button>
              <Button className="btn btn-danger" onClick={() => this.cerrarModalInsertar()}>Cancelar</Button>
            </ModalFooter>
          </Modal>
        </>
      );
    }
  }